These level files will be compiled to lua bytecode.
Available as pdz at runtime, which can be loaded with file.run()
